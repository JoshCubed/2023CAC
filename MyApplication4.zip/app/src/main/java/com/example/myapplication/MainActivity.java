package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


// Calculate the time required to achieve the goal amount
class CompoundInterestCalculator {
    public static double calculateTime(double init, double rate, double amt, double target) {
        double ratePerPeriod = rate / 12;
        double time = 0.0;
        double currentBalance = init;

        while (currentBalance < target) {
            currentBalance += amt;
            currentBalance *= (1 + ratePerPeriod);
            time += 1.0 / 12;
        }

        return time;
    }
}

public class MainActivity extends AppCompatActivity {
    private EditText mInit;
    private EditText mAmt;
    private EditText mRate;
    private EditText mTarget;
    private Button mCalc;
    private TextView mResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mInit = findViewById(R.id.etInit);
        mAmt = findViewById(R.id.etAmt);
        mRate = findViewById(R.id.etRate);
        mTarget = findViewById(R.id.etTarget);
        mCalc = findViewById(R.id.btnCalc);
        mResult = findViewById(R.id.txtResult);

        mCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double Init = Double.parseDouble(mInit.getText().toString());
                double Amt = Double.parseDouble(mAmt.getText().toString());
                double Rate = (Double.parseDouble(mRate.getText().toString()))/100;
                double Target = Double.parseDouble(mTarget.getText().toString());

                double decimalYears;

                decimalYears = CompoundInterestCalculator.calculateTime(Init, Rate, Amt, Target) + 0.083;

                int years = (int) decimalYears;
                int months = (int) ((decimalYears - years) * 12);

                if (months == 0) {
                    mResult.setText(String.valueOf(years + " years "));
                }
                else {
                    mResult.setText(String.valueOf(years + " years " + months + " months"));
                }
            }
        });

    }
}